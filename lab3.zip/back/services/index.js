module.exports = {
    UserService: require('./user.service'),
}