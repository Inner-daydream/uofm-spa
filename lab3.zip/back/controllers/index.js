
module.exports = {
    UserController: require('./user.controller'),
};