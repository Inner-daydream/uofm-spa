<script setup>
import LoginVue from "../components/Login.vue";
</script>

<template>
	<LoginVue></LoginVue>
</template>
