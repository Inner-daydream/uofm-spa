<script setup>
import RegisterForm from '../components/RegisterForm.vue';
</script>
<template>
    <div>
        <h1>Register</h1>
        <RegisterForm></RegisterForm>
    </div>
</template>

<style scoped>
h1 {
    text-align: center;
    margin: 1rem;
}
</style>
