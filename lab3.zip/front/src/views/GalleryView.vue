<script setup>
import Gallery from '../components/Gallery.vue';
</script>
<template>
    <h1>My Lab2 Gallery</h1>
    <Gallery />
</template>

<style scoped>
h1 {
    text-align: center;
    margin: 1rem;
}
</style>
